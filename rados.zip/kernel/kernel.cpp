extern "C" void _start() {
    int i = 0;
    int* vmem = (int*)0xA0000;
    while (1) {
        vmem[i-1] = 0x00;
        vmem[i] = 0x5;
        i++;
        if (i > 640/8*480*4) i = 0;
        for (int j = 0; j < 1000000; j++) {};
    }

    while (1) {};
}